</div>
<!-- Penutup tag .container yang dibuka di header.php -->

<footer style="text-align: center; margin-top: 30px; padding: 15px; background-color: #e9ecef; border-top: 1px solid #dee2e6;">
    <p>© 2024 Framework MVC Sederhana | Modul 9 View</p>
</footer>

<!-- Script JavaScript bisa dimuat di sini -->
<script>
    // Contoh script
    console.log("Footer dimuat.");
</script>
</body>

</html>